var searchData=
[
  ['binddevicetoken_3a',['bindDeviceToken:',['../interface_e_m_client.html#a9c9c332ea31acc6ea6355673e0b8d1bb',1,'EMClient']]],
  ['blacklist',['blacklist',['../interface_e_m_chatroom.html#ab105bc5fdeeeb63b6e4693077735b360',1,'EMChatroom::blacklist()'],['../interface_e_m_group.html#aa482dd20042357f1aae7a854e5b57f59',1,'EMGroup::blacklist()']]],
  ['blockgroup_3acompletion_3a',['blockGroup:completion:',['../protocol_i_e_m_group_manager-p.html#afcf5d675a457d229dbe6429fb4d27450',1,'IEMGroupManager-p']]],
  ['blockgroup_3aerror_3a',['blockGroup:error:',['../protocol_i_e_m_group_manager-p.html#abe0ce6d22dc617c8125e4b17e4502374',1,'IEMGroupManager-p']]],
  ['blockmembers_3afromchatroom_3acompletion_3a',['blockMembers:fromChatroom:completion:',['../protocol_i_e_m_chatroom_manager-p.html#a07354b71c649319baf6e39fae96d522c',1,'IEMChatroomManager-p']]],
  ['blockmembers_3afromchatroom_3aerror_3a',['blockMembers:fromChatroom:error:',['../protocol_i_e_m_chatroom_manager-p.html#a1917e97cceb0eed029c4f6366fec125a',1,'IEMChatroomManager-p']]],
  ['blockmembers_3afromgroup_3acompletion_3a',['blockMembers:fromGroup:completion:',['../protocol_i_e_m_group_manager-p.html#a6949f7d4a92c24988ed6cd07a4c583a4',1,'IEMGroupManager-p']]],
  ['blockoccupants_3afromgroup_3aerror_3a',['blockOccupants:fromGroup:error:',['../protocol_i_e_m_group_manager-p.html#a3c0de93e0076385e1f7a597310f60542',1,'IEMGroupManager-p']]],
  ['body',['body',['../interface_e_m_message.html#a48cb4a1294dc59e271a2b62b669d3ae2',1,'EMMessage']]]
];
