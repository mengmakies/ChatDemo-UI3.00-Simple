var searchData=
[
  ['joinchatroom_3acompletion_3a',['joinChatroom:completion:',['../protocol_i_e_m_chatroom_manager-p.html#a4091826df825b9f1825f2ea97c4fb3e2',1,'IEMChatroomManager-p']]],
  ['joinchatroom_3aerror_3a',['joinChatroom:error:',['../protocol_i_e_m_chatroom_manager-p.html#a32a8775b7719f1426e885f864464fb68',1,'IEMChatroomManager-p']]],
  ['joingrouprequestdidapprove_3a',['joinGroupRequestDidApprove:',['../protocol_e_m_group_manager_delegate-p.html#a1a46522e3bda01d100e7d97766301cf3',1,'EMGroupManagerDelegate-p']]],
  ['joingrouprequestdiddecline_3areason_3a',['joinGroupRequestDidDecline:reason:',['../protocol_e_m_group_manager_delegate-p.html#a04c19455375477181825935349cc4842',1,'EMGroupManagerDelegate-p']]],
  ['joingrouprequestdidreceive_3auser_3areason_3a',['joinGroupRequestDidReceive:user:reason:',['../protocol_e_m_group_manager_delegate-p.html#ad7e38106f3c2471827c0831ee2189885',1,'EMGroupManagerDelegate-p']]],
  ['joinpublicgroup_3acompletion_3a',['joinPublicGroup:completion:',['../protocol_i_e_m_group_manager-p.html#a5da915f6628d0e0b34ac378ec7948bb4',1,'IEMGroupManager-p']]],
  ['joinpublicgroup_3aerror_3a',['joinPublicGroup:error:',['../protocol_i_e_m_group_manager-p.html#ab8a4e26cd835e7bf13a9198c20aed1ec',1,'IEMGroupManager-p']]]
];
