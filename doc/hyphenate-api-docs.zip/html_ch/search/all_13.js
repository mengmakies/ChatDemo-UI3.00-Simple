var searchData=
[
  ['version',['version',['../interface_e_m_client.html#ae0806b1523e5b49381660594a26d4fdf',1,'EMClient']]],
  ['videolatency',['videoLatency',['../interface_e_m_call_session.html#a218b700793cbd72fb0bd1a5556bf0e06',1,'EMCallSession']]],
  ['videoresolution',['videoResolution',['../interface_e_m_call_options.html#af49ac4f01b9bca538fbce40e1de5f866',1,'EMCallOptions']]]
];
