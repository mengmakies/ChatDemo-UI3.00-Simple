var searchData=
[
  ['groupid',['groupId',['../interface_e_m_group.html#a743f373370bfa102f78bfc10b8791102',1,'EMGroup']]],
  ['groupmanager',['groupManager',['../interface_e_m_client.html#a7945b211dc3f2580543235f5009ec7d9',1,'EMClient']]]
];
