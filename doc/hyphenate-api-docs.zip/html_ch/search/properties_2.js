var searchData=
[
  ['callid',['callId',['../interface_e_m_call_session.html#a66283c44edfc5ae767b382f63176d953',1,'EMCallSession']]],
  ['callmanager',['callManager',['../category_e_m_client_07_call_08.html#ab535b8eb47ca4487e4bffc462f9e581c',1,'EMClient(Call)::callManager()'],['../interface_e_m_client.html#ab535b8eb47ca4487e4bffc462f9e581c',1,'EMClient::callManager()']]],
  ['chatmanager',['chatManager',['../interface_e_m_client.html#a7a663c262efac7cf04bc27aa4764a2a2',1,'EMClient']]],
  ['chatport',['chatPort',['../category_e_m_options_07_private_deploy_08.html#add8ffc7906a0b90c66402014173b6e69',1,'EMOptions(PrivateDeploy)::chatPort()'],['../interface_e_m_options.html#add8ffc7906a0b90c66402014173b6e69',1,'EMOptions::chatPort()']]],
  ['chatroomid',['chatroomId',['../interface_e_m_chatroom.html#ac0344329548b41dba863c8f6b4a4b9ce',1,'EMChatroom']]],
  ['chatserver',['chatServer',['../category_e_m_options_07_private_deploy_08.html#a48eef5818d35875db7aefa7cb6991c97',1,'EMOptions(PrivateDeploy)::chatServer()'],['../interface_e_m_options.html#a48eef5818d35875db7aefa7cb6991c97',1,'EMOptions::chatServer()']]],
  ['chattype',['chatType',['../interface_e_m_message.html#aab839095b6ca5d54ba48a4fa18342b34',1,'EMMessage']]],
  ['code',['code',['../interface_e_m_error.html#a1afcdf4484d6ac443e76e4b360c02969',1,'EMError']]],
  ['connecttype',['connectType',['../interface_e_m_call_session.html#ab31443f1605498f4bb80a4e98925fecb',1,'EMCallSession']]],
  ['contactmanager',['contactManager',['../interface_e_m_client.html#aabe23dfa1c1d2dcc7a4a577baf2b953a',1,'EMClient']]],
  ['conversationid',['conversationId',['../interface_e_m_conversation.html#adadfc8b72fb52e6ec461417ac9e26221',1,'EMConversation::conversationId()'],['../interface_e_m_message.html#a3f7b43164e1ad4fe438db195735de5c3',1,'EMMessage::conversationId()']]],
  ['currentusername',['currentUsername',['../interface_e_m_client.html#adc532d66ce6e2dece51af2aadbe2ea31',1,'EMClient']]],
  ['cursor',['cursor',['../interface_e_m_cursor_result.html#a3f85d9a83ed3d5851e18b185322b44a2',1,'EMCursorResult']]]
];
