var searchData=
[
  ['fetchchatroominfo_3aincludememberslist_3aerror_3a',['fetchChatroomInfo:includeMembersList:error:',['../protocol_i_e_m_chatroom_manager-p.html#adcf0ce5b763bba2ef99dac82c1f86584',1,'IEMChatroomManager-p']]],
  ['fetchgroupbanslist_3aerror_3a',['fetchGroupBansList:error:',['../protocol_i_e_m_group_manager-p.html#a46c71572bf27c1361e8823a6f5f97d34',1,'IEMGroupManager-p']]],
  ['fetchgroupinfo_3aincludememberslist_3aerror_3a',['fetchGroupInfo:includeMembersList:error:',['../protocol_i_e_m_group_manager-p.html#aee4dd02354d8a98e15659993f5c46bb8',1,'IEMGroupManager-p']]],
  ['filelength',['fileLength',['../interface_e_m_file_message_body.html#a8e4da770841aacd07f8e07d76e58e591',1,'EMFileMessageBody']]],
  ['friendrequestdidapprovebyuser_3a',['friendRequestDidApproveByUser:',['../protocol_e_m_contact_manager_delegate-p.html#a9c98c065b0ae91c3cb120a831cd91a02',1,'EMContactManagerDelegate-p']]],
  ['friendrequestdiddeclinebyuser_3a',['friendRequestDidDeclineByUser:',['../protocol_e_m_contact_manager_delegate-p.html#a31cc6e8da8de6eb9bdd78bf62eb0c29e',1,'EMContactManagerDelegate-p']]],
  ['friendrequestdidreceivefromuser_3amessage_3a',['friendRequestDidReceiveFromUser:message:',['../protocol_e_m_contact_manager_delegate-p.html#a73ea8e66ff288c57d62ce4e56977bcef',1,'EMContactManagerDelegate-p']]],
  ['friendshipdidaddbyuser_3a',['friendshipDidAddByUser:',['../protocol_e_m_contact_manager_delegate-p.html#a4d26a7e11f26cee937d85cf90b5acfa9',1,'EMContactManagerDelegate-p']]],
  ['friendshipdidremovebyuser_3a',['friendshipDidRemoveByUser:',['../protocol_e_m_contact_manager_delegate-p.html#ab94cc7e60ad629005de79185fe1cef79',1,'EMContactManagerDelegate-p']]],
  ['from',['from',['../interface_e_m_message.html#ad173eaa1fa087d95a81c16e0b23a058f',1,'EMMessage']]]
];
