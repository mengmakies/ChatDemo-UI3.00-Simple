var searchData=
[
  ['takeremotepicture_3a',['takeRemotePicture:',['../interface_e_m_call_session.html#ac2e2ba11bfba6ed5b753e68828f18bda',1,'EMCallSession']]]
];
