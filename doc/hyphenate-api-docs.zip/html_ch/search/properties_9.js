var searchData=
[
  ['maxuserscount',['maxUsersCount',['../interface_e_m_group_options.html#a363499589cbb9040619c9a64c2ad27e9',1,'EMGroupOptions']]],
  ['maxvideoframerate',['maxVideoFrameRate',['../interface_e_m_call_options.html#a45f020f84b4513fdc0cb3f8a123fe678',1,'EMCallOptions']]],
  ['maxvideokbps',['maxVideoKbps',['../interface_e_m_call_options.html#a4130c8f7488d6d6f58c3783dc63be5fd',1,'EMCallOptions']]],
  ['members',['members',['../interface_e_m_group.html#a100605134c905e8ba3b4a24436fc0158',1,'EMGroup']]],
  ['messageid',['messageId',['../interface_e_m_message.html#a3a85be4426c1f17888b8cb614c9e537c',1,'EMMessage']]],
  ['minvideokbps',['minVideoKbps',['../interface_e_m_call_options.html#ae070e260597c913634a21c03aa31826a',1,'EMCallOptions']]]
];
