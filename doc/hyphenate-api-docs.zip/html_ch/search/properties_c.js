var searchData=
[
  ['params',['params',['../interface_e_m_cmd_message_body.html#a20bc77479a764510867c09f6ff62af54',1,'EMCmdMessageBody']]],
  ['permissiontype',['permissionType',['../interface_e_m_chatroom.html#a88c3a5ddde2cc67aad2bff7ad5c72fa0',1,'EMChatroom::permissionType()'],['../interface_e_m_group.html#aa2c03fbb097e27cd609e75d5e9843c33',1,'EMGroup::permissionType()']]],
  ['pushoptions',['pushOptions',['../interface_e_m_client.html#a4dd459e3f06535ef62f38f53769333ed',1,'EMClient']]]
];
