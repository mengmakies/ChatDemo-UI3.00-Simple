var searchData=
[
  ['binddevicetoken_3a',['bindDeviceToken:',['../interface_e_m_client.html#a9c9c332ea31acc6ea6355673e0b8d1bb',1,'EMClient']]],
  ['blockgroup_3acompletion_3a',['blockGroup:completion:',['../protocol_i_e_m_group_manager-p.html#afcf5d675a457d229dbe6429fb4d27450',1,'IEMGroupManager-p']]],
  ['blockgroup_3aerror_3a',['blockGroup:error:',['../protocol_i_e_m_group_manager-p.html#abe0ce6d22dc617c8125e4b17e4502374',1,'IEMGroupManager-p']]],
  ['blockmembers_3afromgroup_3acompletion_3a',['blockMembers:fromGroup:completion:',['../protocol_i_e_m_group_manager-p.html#a6949f7d4a92c24988ed6cd07a4c583a4',1,'IEMGroupManager-p']]],
  ['blockoccupants_3afromgroup_3aerror_3a',['blockOccupants:fromGroup:error:',['../protocol_i_e_m_group_manager-p.html#a3c0de93e0076385e1f7a597310f60542',1,'IEMGroupManager-p']]]
];
