var searchData=
[
  ['calldidaccept_3a',['callDidAccept:',['../protocol_e_m_call_manager_delegate-p.html#aa0f4c7b3f5a9c6613f6726420910e76c',1,'EMCallManagerDelegate-p']]],
  ['calldidconnect_3a',['callDidConnect:',['../protocol_e_m_call_manager_delegate-p.html#a5203fbf604e29cacedf483c5f52b9923',1,'EMCallManagerDelegate-p']]],
  ['calldidend_3areason_3aerror_3a',['callDidEnd:reason:error:',['../protocol_e_m_call_manager_delegate-p.html#a82a5133f2175c94c4b39cf6f42010601',1,'EMCallManagerDelegate-p']]],
  ['calldidreceive_3a',['callDidReceive:',['../protocol_e_m_call_manager_delegate-p.html#a3eba09d467fd76b4af04e5bf47154b77',1,'EMCallManagerDelegate-p']]],
  ['callnetworkdidchange_3astatus_3a',['callNetworkDidChange:status:',['../protocol_e_m_call_manager_delegate-p.html#aae5150a53d6c69c278b9bdde4cac2022',1,'EMCallManagerDelegate-p']]],
  ['callstatedidchange_3atype_3a',['callStateDidChange:type:',['../protocol_e_m_call_manager_delegate-p.html#a3b78b91a87d76a4ec5f79f60cb213228',1,'EMCallManagerDelegate-p']]],
  ['changedescription_3aforgroup_3aerror_3a',['changeDescription:forGroup:error:',['../protocol_i_e_m_group_manager-p.html#abf9fda9a1df498d36716301814417280',1,'IEMGroupManager-p']]],
  ['changegroupsubject_3aforgroup_3aerror_3a',['changeGroupSubject:forGroup:error:',['../protocol_i_e_m_group_manager-p.html#a090b2759d586d91044f439ee111e2b3d',1,'IEMGroupManager-p']]],
  ['chatroomwithid_3a',['chatroomWithId:',['../interface_e_m_chatroom.html#a47814fcec0824c7417ed3f69202f4aec',1,'EMChatroom']]],
  ['cmdmessagesdidreceive_3a',['cmdMessagesDidReceive:',['../protocol_e_m_chat_manager_delegate-p.html#aa053cba8206700f0635fa3db310a8717',1,'EMChatManagerDelegate-p']]],
  ['connectionstatedidchange_3a',['connectionStateDidChange:',['../protocol_e_m_client_delegate-p.html#adf175d117ada98617c054bacf4c11dcb',1,'EMClientDelegate-p']]],
  ['conversationlistdidupdate_3a',['conversationListDidUpdate:',['../protocol_e_m_chat_manager_delegate-p.html#a32d53c14b6d26041120ba521fef6e2f5',1,'EMChatManagerDelegate-p']]],
  ['creategroupwithsubject_3adescription_3ainvitees_3amessage_3asetting_3acompletion_3a',['createGroupWithSubject:description:invitees:message:setting:completion:',['../protocol_i_e_m_group_manager-p.html#a9811c38c880660212ec17771fa1cf870',1,'IEMGroupManager-p']]],
  ['creategroupwithsubject_3adescription_3ainvitees_3amessage_3asetting_3aerror_3a',['createGroupWithSubject:description:invitees:message:setting:error:',['../protocol_i_e_m_group_manager-p.html#ae54181cbadb18880c8264c743d3a05cd',1,'IEMGroupManager-p']]],
  ['cursorresultwithlist_3aandcursor_3a',['cursorResultWithList:andCursor:',['../interface_e_m_cursor_result.html#ad277e648781862b9b45ff595929b2465',1,'EMCursorResult']]]
];
